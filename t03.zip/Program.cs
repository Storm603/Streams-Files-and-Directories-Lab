﻿using System;
using System.IO;

namespace LineNumbers
{
    public class LineNumbers
    {
        static void Main(string[] args)
        {
            string inputFilePath = @"..\..\..\Files\input.txt";
            string outputFilePath = @"..\..\..\Files\output.txt";

            RewriteFileWithLineNumbers(inputFilePath, outputFilePath);
        }

        public static void RewriteFileWithLineNumbers(string inputFilePath, string outputFilePath)
        {
            int index = 0;
            using (StreamReader read = new StreamReader(inputFilePath))
            {
                using (StreamWriter writer = new StreamWriter(outputFilePath))
                {
                    string line = string.Empty;
                    while ((line = read.ReadLine()) != null)
                    {
                        index++;
                        writer.WriteLine($" {line}");
                    }
                }
            }
        }
    }
}
