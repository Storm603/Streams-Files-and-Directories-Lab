﻿using System;
using System.IO;
using System.Linq;

namespace MergeBinaryFiles
{
    class SplitMergeBinaryFile
    {
        static void Main(string[] args)
        {
            string sourceFilePath = @"..\..\..\Files\example.png";
            string partOneFilePath = @"..\..\..\Files\part-1.bin";
            string partTwoFilePath = @"..\..\..\Files\part-2.bin";
            string joinedFilePath = @"..\..\..\Files\example-joined.png";

            SplitBinaryFile(sourceFilePath, partOneFilePath, partTwoFilePath);
            MergeBinaryFiles(partOneFilePath, partTwoFilePath, joinedFilePath);
        }

        public static void SplitBinaryFile(string sourceFilePath, string partOneFilePath, string partTwoFilePath)
        {
            byte[] totalFileBytes = File.ReadAllBytes(sourceFilePath);

            int length = totalFileBytes.Length / 2;

            byte[] partOne = null;
            byte[] partTwo = null;

            if (length % 2 == 0)
            {
                partOne = new byte[length / 2];
                partTwo = new byte[length / 2];
            }
            else
            {
                partOne = new byte[(length / 2) + 1];
                partTwo = new byte[length / 2];
            }

            for (int i = 0; i < partOne.Length; i++)
            {
                partOne[i] = totalFileBytes[i];
            }

            for (int i = 0; i < partTwo.Length; i++)
            {
                partTwo[i] = totalFileBytes[partOne.Length + i];
            }

            using (FileStream writePartOne = new FileStream(partOneFilePath, FileMode.Create))
            {
                writePartOne.Write(partOne);
            }

            using (FileStream writePartTwo = new FileStream(partTwoFilePath, FileMode.Create))
            {
                writePartTwo.Write(partTwo);
            }
        }



        public static void MergeBinaryFiles(string partOneFilePath, string partTwoFilePath, string joinedFilePath)
        {
            byte[] first = File.ReadAllBytes(partOneFilePath);
            byte[] second = File.ReadAllBytes(partTwoFilePath);

            byte[] finished = new byte[first.Length + second.Length];

            for (int i = 0; i < first.Length; i++)
            {
                finished[i] = first[i];
            }

            for (int i = 0; i < second.Length; i++)
            {
                finished[first.Length + i] = second[i];
            }
            using (FileStream write = new FileStream(joinedFilePath, FileMode.Create))
            {
                write.Write(finished);
            }
        }
    }
}
