﻿using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace ExtractBytesFromBinaryFile
{
    class ExtractBytes
    {
        static void Main(string[] args)
        {
            string binaryFilePath = @"..\..\..\Files\example.png";
            string bytesFilePath = @"..\..\..\Files\bytes.txt";
            string outputPath = @"..\..\..\Files\output.bin";

            ExtractBytesFromBinaryFile(binaryFilePath, bytesFilePath, outputPath);
        }

        public static void ExtractBytesFromBinaryFile(string binaryFilePath, string bytesFilePath, string outputPath)
        {

            StreamReader readBytes = new StreamReader(bytesFilePath);
            byte[] bytes = readBytes.ReadToEnd().Split(Environment.NewLine).Select(byte.Parse).ToArray();
            readBytes.Close();
            
            byte[] arr = File.ReadAllBytes(binaryFilePath);

            using (StreamWriter write = new StreamWriter(outputPath))
            {
                foreach (byte byter in arr)
                {
                    if (bytes.Contains(byter))
                    {
                        write.Write(byter + Environment.NewLine);
                    }
                }
            }
        }
    }
}
