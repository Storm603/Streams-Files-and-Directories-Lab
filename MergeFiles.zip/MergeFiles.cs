﻿using System;
using System.IO;

namespace MergeFiles
{
    public class MergeFiles
    {
        static void Main(string[] args)
        {
            string firstInputFilePath = @"..\..\..\Files\input1.txt";
            string secondInputFilePath = @"..\..\..\Files\input2.txt";
            string outputFilePath = @"..\..\..\Files\output.txt";

            MergeTextFiles(firstInputFilePath, secondInputFilePath, outputFilePath);
        }

        public static void MergeTextFiles(string firstInputFilePath, string secondInputFilePath, string outputFilePath)
        {
            StreamReader reader1 = new StreamReader(firstInputFilePath);
            StreamReader reader2 = new StreamReader(secondInputFilePath);


            using (StreamWriter writer = new StreamWriter(outputFilePath))
            {
                while (true)
                {
                    string r1 = reader1.ReadLine();
                    string r2 = reader2.ReadLine();

                    if (r1 != null)
                    {
                        writer.WriteLine(r1);
                    }

                    if (r2 != null)
                    {
                        writer.WriteLine(r2);
                    }

                    if (r1 == null  && r2 == null)
                    {
                        break;
                    }
                }
            }

            reader1.Close();
            reader2.Close();
        }
    }
}
