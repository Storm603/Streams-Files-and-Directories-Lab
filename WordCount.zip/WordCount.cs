﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace WordCount
{
    public class WordCount
    {
        //static void Main(string[] args)
        //{
        //    string wordsFilePath = @"..\..\..\Files\words.txt";
        //    string textFilePath = @"..\..\..\Files\text.txt";
        //    string outputFilePath = @"..\..\..\Files\output.txt";
        //    CalculateWordCounts(wordsFilePath, textFilePath, outputFilePath);
        //}

        public static void CalculateWordCounts(string wordsFilePath, string textFilePath, string outputFilePath)
        {
            StreamReader reader = new StreamReader(wordsFilePath);
            string[] words = reader.ReadLine().Split();
            reader.Close();

            Dictionary<string, int> hits = new Dictionary<string, int>();

            foreach (string word in words)
            {
                hits.Add(word, 0);
            }

            using (StreamReader text = new StreamReader(textFilePath))
            {
                string wordo = String.Empty;
                while ((wordo = text.ReadLine()) != null)
                {
                    string[] wordss = wordo.Split(new char[]{'-', ',','.', ' '});

                    foreach (string word in wordss)
                    {
                        if (hits.ContainsKey(word.ToLower()))
                        {
                            hits[word.ToLower()]++;
                        }
                    }
                }
            }

            using (var putput = new StreamWriter(outputFilePath))
            {
                foreach (KeyValuePair<string, int> hit in hits.OrderByDescending(x => x.Value))
                {
                    putput.WriteLine($"{hit.Key} - {hit.Value}");
                }
            }
        }
    }
}
