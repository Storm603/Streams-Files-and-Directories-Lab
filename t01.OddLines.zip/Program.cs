﻿using System;
using System.IO;

namespace OddLines
{
    public class OddLines
    {
        static void Main(string[] args)
        {
            string inputFilePath = @"..\..\..\Files\input.txt";
            string outputFilePath = @"..\..\..\Files\output.txt";

            ExtractOddLines(inputFilePath, outputFilePath);
        }

        public static void ExtractOddLines(string inputFilePath, string outputFilePath)
        {
            int index = 0;
            using (StreamReader read = new StreamReader(inputFilePath))
            {
                using (StreamWriter writer = new StreamWriter(outputFilePath))
                {
                    string line = string.Empty;
                    while ((line = read.ReadLine()) != null)
                    {
                        if (index % 2 == 1)
                        {
                            writer.WriteLine(line);
                        }
                        index++;
                    }
                }
            }
        }
    }
}
